import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridBagLayout;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class PhotoViewer {

    private JFrame frame;
    private PhotographContainer imageAlbum;
    private ArrayList<Photograph> photos;
    private int currentPhotoIndex = 0;
    private Photograph currentPhoto;

    private HashMap<Photograph, ImageIcon> photoToThumbnailsImgIcon = new HashMap<>();
    private HashMap<Photograph, ImageIcon> photoToDisplayImgIcon = new HashMap<>();

    private JLabel lblDisplay;
    private ArrayList<JLabel> lblThumbnails = new ArrayList<>();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {

        PhotoViewer myViewer = new PhotoViewer();
        ArrayList<Photograph> photos = new ArrayList<>();
        Photograph p1 = new Photograph("./images/1.jpg", "Drone", "2010-01-01", 1);
        Photograph p2 = new Photograph("./images/2.jpg", "Phone", "2011-02-02", 2);
        Photograph p3 = new Photograph("./images/3.jpg", "Voyage", "2013-03-03", 3);
        Photograph p4 = new Photograph("./images/4.jpg", "Portait", "2014-04-04", 4);
        Photograph p5 = new Photograph("./images/5.jpg", "Fried", "2015-05-05", 5);
        photos.add(p2);
        photos.add(p1);
        photos.add(p3);
        photos.add(p4);
        photos.add(p5);
        myViewer.addPhotos(photos);

        EventQueue.invokeLater(() -> {
            try {
                myViewer.createAndShowGUI();
                myViewer.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
    }

    /**
     * Create the application.
     */
    public PhotoViewer() {
        imageAlbum = new Album("");
    }

    /**
     * Initialize the contents of the frame.
     * 
     * @wbp.parser.entryPoint
     */
    private void createAndShowGUI() {
        photos = imageAlbum.getPhotos();
        frame = new JFrame();
        frame.setBounds(100, 100, 850, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GridBagLayout gridBagLayout = new GridBagLayout();
        gridBagLayout.columnWidths = new int[] { 400, 450 };
        gridBagLayout.rowHeights = new int[] { 50, 500, 50 };
        gridBagLayout.columnWeights = new double[] { 0.0, 1.0 };
        gridBagLayout.rowWeights = new double[] { 0.0, 1.0, 0.0 };
        frame.getContentPane().setLayout(gridBagLayout);

        // cache icons and set sizes
        createThumbnailsImgIcons(200, 10000);
        createDisplayImgIcons(gridBagLayout.columnWidths[1] - 50, gridBagLayout.rowHeights[1]);
        currentPhoto = photos.get(currentPhotoIndex);

        JPanel toolBar = new JPanel();
        GridBagConstraints gbc_toolBar = new GridBagConstraints();
        gbc_toolBar.insets = new Insets(0, 0, 5, 0);
        gbc_toolBar.gridwidth = 2;
        gbc_toolBar.fill = GridBagConstraints.BOTH;
        gbc_toolBar.gridx = 0;
        gbc_toolBar.gridy = 0;
        frame.getContentPane().add(toolBar, gbc_toolBar);
        toolBar.setLayout(new GridLayout(1, 6, 0, 0));

        JButton btnExit = new JButton("Exit");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        toolBar.add(btnExit);

        JButton btnPrev = new JButton("Prev");
        btnPrev.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cyclePhotoIndex(false);
                updateLblDisplay();
            }
        });
        toolBar.add(btnPrev);

        JButton btnNext = new JButton("Next");
        btnNext.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cyclePhotoIndex(true);
                updateLblDisplay();
            }
        });
        toolBar.add(btnNext);

        JButton btnSortByDate = new JButton("Sort by date");
        btnSortByDate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Collections.sort(photos);
                currentPhotoIndex = photos.indexOf(currentPhoto);
                updateLblThumbnails();
            }
        });
        toolBar.add(btnSortByDate);

        JButton btnSortByCaption = new JButton("Sort by caption");
        btnSortByCaption.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Collections.sort(photos, new CompareByCaption());
                currentPhotoIndex = photos.indexOf(currentPhoto);
                updateLblThumbnails();
            }
        });
        toolBar.add(btnSortByCaption);

        JButton btnSortByRating = new JButton("Sort by rating");
        btnSortByRating.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Collections.sort(photos, new CompareByRating());
                currentPhotoIndex = photos.indexOf(currentPhoto);
                updateLblThumbnails();
            }
        });
        toolBar.add(btnSortByRating);

        JScrollPane scpThumbnails = new JScrollPane();
        GridBagConstraints gbc_scpThumbnails = new GridBagConstraints();
        gbc_scpThumbnails.fill = GridBagConstraints.BOTH;
        gbc_scpThumbnails.gridheight = 2;
        gbc_scpThumbnails.insets = new Insets(0, 0, 5, 5);
        gbc_scpThumbnails.gridx = 0;
        gbc_scpThumbnails.gridy = 1;
        frame.getContentPane().add(scpThumbnails, gbc_scpThumbnails);

        JPanel pnlThumbnails = new JPanel();
        scpThumbnails.setViewportView(pnlThumbnails);
        pnlThumbnails.setLayout(new GridLayout(photos.size(), 1, 0, 0));

        // add thumbnail labels
        lblThumbnails = new ArrayList<>();
        for (Photograph p : photos) {
            JLabel lblThumbnail = new JLabel();
            lblThumbnail.setText(p.createStrThumbnailInfo());
            lblThumbnail.setIcon(photoToThumbnailsImgIcon.get(p));
            lblThumbnail.setHorizontalTextPosition(JLabel.RIGHT);
            lblThumbnail.setVerticalTextPosition(JLabel.CENTER);
            lblThumbnail.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    int indexOfLabel = lblThumbnails.indexOf(e.getSource());
                    currentPhotoIndex = indexOfLabel;
                    updateLblDisplay();
                }
            });
            lblThumbnails.add(lblThumbnail);
            pnlThumbnails.add(lblThumbnail);
        }

        JLabel lblDisplay = new JLabel("");
        this.lblDisplay = lblDisplay;
        lblDisplay.setIcon(photoToDisplayImgIcon.get(currentPhoto));
        GridBagConstraints gbc_lblDisplay = new GridBagConstraints();
        gbc_lblDisplay.insets = new Insets(0, 0, 5, 0);
        gbc_lblDisplay.gridx = 1;
        gbc_lblDisplay.gridy = 1;
        frame.getContentPane().add(lblDisplay, gbc_lblDisplay);

        JPanel pnlRater = new JPanel();
        GridBagConstraints gbc_pnlRater = new GridBagConstraints();
        gbc_pnlRater.fill = GridBagConstraints.BOTH;
        gbc_pnlRater.gridx = 1;
        gbc_pnlRater.gridy = 2;
        frame.getContentPane().add(pnlRater, gbc_pnlRater);
        pnlRater.setLayout(new GridLayout(1, 6, 0, 0));
        JLabel lblRating = new JLabel("Rating: ");
        lblRating.setHorizontalAlignment(JLabel.RIGHT);
        pnlRater.add(lblRating);

        // add rater buttons
        for (int i = 1; i <= 5; i++) {
            JButton btnRating = new JButton(String.valueOf(i));
            btnRating.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    JButton clicked = (JButton) e.getSource();
                    int newRating = Integer.valueOf(clicked.getText());
                    currentPhoto.setRating(newRating);
                    lblThumbnails.get(currentPhotoIndex).setText(currentPhoto.createStrThumbnailInfo());
                }
            });
            pnlRater.add(btnRating);
        }

    }

    private void createDisplayImgIcons(int width, int height) {
        for (Photograph p : imageAlbum.getPhotos()) {
            ImageIcon i = createImgIconFromPhoto(p, width, height);
            photoToDisplayImgIcon.put(p, i);
        }
    }

    private void createThumbnailsImgIcons(int width, int height) {
        for (Photograph p : imageAlbum.getPhotos()) {
            ImageIcon i = createImgIconFromPhoto(p, width, height);
            photoToThumbnailsImgIcon.put(p, i);
        }
    }

    private ImageIcon createImgIconFromPhoto(Photograph p, int width, int height) {
        ImageIcon icon = new ImageIcon(p.getImagefile().getPath());
        resizeIconProportionately(icon, width, height);
        return icon;
    }

    /**
     * resize imgIcon to fit in a rectangle of desired size without changing it's
     * proportions.
     */
    private void resizeIconProportionately(ImageIcon targetIcon, int newWidth, int newHeight) {
        double widthProportion = (double) newWidth / targetIcon.getIconWidth();
        double heightProportion = (double) newHeight / targetIcon.getIconHeight();
        double scaleCoefficient = widthProportion < heightProportion ? widthProportion : heightProportion;
        scaleImgIcon(targetIcon, scaleCoefficient);
    }

    /**
     * scales an ImageIcon by multiplying its dimensions by scaleCoefficient
     */
    private void scaleImgIcon(ImageIcon imgIcon, double scaleCoefficient) {
        Image img = imgIcon.getImage();
        int newWidth = (int) (imgIcon.getIconWidth() * scaleCoefficient);
        int newHeight = (int) (imgIcon.getIconHeight() * scaleCoefficient);
        Image newImg = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        imgIcon.setImage(newImg);
    }

    private void addPhotos(ArrayList<Photograph> photosToAdd) {
        for (Photograph p : photosToAdd) {
            this.imageAlbum.addPhoto(p);
        }
    }

    private void cyclePhotoIndex(boolean next) {
        int newIndex = this.currentPhotoIndex;
        if (next) {
            newIndex += 1;
        } else {
            newIndex -= 1;
        }
        newIndex = Math.floorMod(newIndex, this.imageAlbum.getPhotos().size());
        this.currentPhotoIndex = newIndex;
    }

    private void updateLblDisplay() {
        currentPhoto = photos.get(currentPhotoIndex);
        lblDisplay.setIcon(photoToDisplayImgIcon.get(currentPhoto));
    }

    private void updateLblThumbnails() {
        for (int i = 0; i < photos.size(); i++) {
            JLabel l = lblThumbnails.get(i);
            Photograph p = photos.get(i);
            l.setIcon(photoToThumbnailsImgIcon.get(p));
            l.setText(p.createStrThumbnailInfo());
        }
    }
}
