
/**
* Homework 5 <br>
* Simeng Hao, sh4aj <br>
* Source: N/A <br>
*/
/**
 * Album
 */
public class Album extends PhotographContainer {

    public Album(String albumName) {
        super(albumName);
    }

}
